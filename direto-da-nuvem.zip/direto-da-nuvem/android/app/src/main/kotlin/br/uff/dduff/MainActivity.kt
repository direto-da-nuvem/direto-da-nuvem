package br.uff.dduff

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
